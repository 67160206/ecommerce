import { SignJWT, jwtVerify } from 'jose'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { db } from './db'
const key = () => new TextEncoder().encode(process.env.AUTH_SECRET || 'dev-secret-change-me')
export async function setSession(id: number) {
  const t = await new SignJWT({ id }).setProtectedHeader({ alg: 'HS256' }).setExpirationTime('7d').sign(key())
  cookies().set('tok', t, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 604800 })
}
export async function getUser() {
  const t = cookies().get('tok')?.value
  if (!t) return null
  try { const { payload } = await jwtVerify(t, key()); return await db.user.findUnique({ where: { id: Number(payload.id) } }) } catch { return null }
}
export async function requireUser(next = '/') {
  const u = await getUser()
  if (!u) redirect('/login?next=' + encodeURIComponent(next))
  return u
}
export async function requireAdmin() {
  const u = await requireUser('/admin')
  if (u.role !== 'ADMIN') redirect('/')
  return u
}
