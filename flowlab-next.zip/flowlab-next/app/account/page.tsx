import Link from 'next/link'
import { db } from '@/lib/db'
import { requireUser } from '@/lib/auth'
import { baht } from '@/lib/utils'
import { StatusBadge, Table, btn } from '@/components/ui'
export default async function Orders() {
  const u = await requireUser('/account')
  const os = await db.order.findMany({ where: { userId: u.id }, orderBy: { id: 'desc' } })
  if (!os.length) return <p className="text-slate-500">ยังไม่มีคำสั่งซื้อ</p>
  return <Table><thead><tr><th>เลขที่</th><th>วันที่</th><th>ยอดรวม</th><th>สถานะ</th><th></th></tr></thead><tbody>
    {os.map(o => <tr key={o.id}><td>#{o.id}</td><td>{o.createdAt.toLocaleDateString('th-TH')}</td><td>{baht(o.totalAmount)}</td><td><StatusBadge s={o.status} /></td><td><Link href={`/order/${o.id}`} className={btn('outline', 'px-3 py-1')}>ดูรายละเอียด</Link></td></tr>)}</tbody></Table>
}
