import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { setSession } from '@/lib/auth'
const err = (error: string, status: number) => NextResponse.json({ error }, { status })
export async function POST(req: Request, { params }: { params: { action: string } }) {
  if (params.action === 'logout') { cookies().delete('tok'); return NextResponse.redirect(new URL('/', req.url), 303) }
  const b = await req.json().catch(() => ({}))
  const email = String(b.email || '').trim().toLowerCase(), pw = String(b.password || '')
  if (params.action === 'register') {
    const name = String(b.name || '').trim()
    if (!name || !/^\S+@\S+$/.test(email) || pw.length < 6) return err('กรอกชื่อ อีเมลที่ถูกต้อง และรหัสผ่านอย่างน้อย 6 ตัวอักษร', 400)
    if (await db.user.findUnique({ where: { email } })) return err('อีเมลนี้ถูกใช้แล้ว', 409)
    const u = await db.user.create({ data: { name, email, passwordHash: await bcrypt.hash(pw, 10) } })
    await setSession(u.id)
    return NextResponse.json({ ok: true })
  }
  if (params.action === 'login') {
    const u = await db.user.findUnique({ where: { email } })
    if (!u || !(await bcrypt.compare(pw, u.passwordHash))) return err('อีเมลหรือรหัสผ่านไม่ถูกต้อง', 401)
    await setSession(u.id)
    return NextResponse.json({ ok: true })
  }
  return err('not found', 404)
}
