import { db } from '@/lib/db'
export const dynamic = 'force-dynamic'
export const GET = async () => Response.json(await db.category.findMany({ orderBy: { id: 'asc' } }))
