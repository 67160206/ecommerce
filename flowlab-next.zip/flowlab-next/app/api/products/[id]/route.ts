import { db } from '@/lib/db'
export const dynamic = 'force-dynamic'
export async function GET(_: Request, { params }: { params: { id: string } }) {
  const p = await db.product.findUnique({ where: { id: Number(params.id) } })
  return p && p.isActive ? Response.json(p) : Response.json({ error: 'ไม่พบสินค้า' }, { status: 404 })
}
