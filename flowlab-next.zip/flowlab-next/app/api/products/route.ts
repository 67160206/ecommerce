import { db } from '@/lib/db'
export const dynamic = 'force-dynamic'
export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams, c = Number(sp.get('category')) || 0
  return Response.json(await db.product.findMany({ where: { isActive: true, name: { contains: sp.get('q') || '' }, ...(c ? { categoryId: c } : {}) }, orderBy: { id: 'asc' } }))
}
