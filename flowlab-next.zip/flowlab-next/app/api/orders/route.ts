import { db } from '@/lib/db'
import { getUser } from '@/lib/auth'
export const dynamic = 'force-dynamic'
export async function GET() {
  const u = await getUser()
  if (!u) return Response.json({ error: 'กรุณาเข้าสู่ระบบ' }, { status: 401 })
  return Response.json(await db.order.findMany({ where: u.role === 'ADMIN' ? {} : { userId: u.id }, include: { items: true }, orderBy: { id: 'desc' } }))
}
export async function POST(req: Request) {
  const u = await getUser()
  if (!u) return Response.json({ error: 'กรุณาเข้าสู่ระบบ' }, { status: 401 })
  const b = await req.json().catch(() => ({}))
  const items: { id: number; qty: number }[] = Array.isArray(b.items) ? b.items : []
  const name = String(b.name || '').trim(), phone = String(b.phone || '').trim(), addr = String(b.address || '').trim()
  if (!items.length || !name || !phone || !addr) return Response.json({ error: 'กรอกข้อมูลจัดส่งให้ครบและเลือกสินค้าอย่างน้อย 1 รายการ' }, { status: 400 })
  try {
    const order = await db.$transaction(async tx => {
      let total = 0
      const lines: { productId: number; quantity: number; unitPrice: number }[] = []
      for (const i of items) {
        const p = await tx.product.findUnique({ where: { id: Number(i.id) } }), q = Math.floor(Number(i.qty))
        if (!p || !p.isActive || !(q > 0)) throw new Error('มีสินค้าที่ไม่พร้อมขาย')
        const r = await tx.product.updateMany({ where: { id: p.id, stock: { gte: q } }, data: { stock: { decrement: q } } })
        if (!r.count) throw new Error(`“${p.name}” มีสต็อกไม่พอ`)
        total += p.price * q
        lines.push({ productId: p.id, quantity: q, unitPrice: p.price })
      }
      return tx.order.create({ data: { userId: u.id, totalAmount: total, shippingName: name, shippingPhone: phone, shippingAddress: addr, items: { create: lines } } })
    })
    return Response.json({ id: order.id })
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : 'สั่งซื้อไม่สำเร็จ' }, { status: 409 })
  }
}
