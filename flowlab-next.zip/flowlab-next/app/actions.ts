'use server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { db } from '@/lib/db'
import { requireUser, requireAdmin } from '@/lib/auth'
const s = (f: FormData, k: string) => String(f.get(k) ?? '').trim()

export async function saveProfile(f: FormData) {
  const u = await requireUser('/account/profile')
  await db.user.update({ where: { id: u.id }, data: { name: s(f, 'name') || u.name, phone: s(f, 'phone') } })
  revalidatePath('/account/profile')
}
export async function saveAddress(f: FormData) {
  const u = await requireUser('/account/profile')
  const id = Number(f.get('id')) || 0
  const d = { fullName: s(f, 'fullName'), phone: s(f, 'phone'), line1: s(f, 'line1'), district: s(f, 'district'), province: s(f, 'province'), postalCode: s(f, 'postalCode'), isDefault: f.get('isDefault') === 'on' }
  if (!d.fullName || !d.line1) return
  if (d.isDefault) await db.address.updateMany({ where: { userId: u.id }, data: { isDefault: false } })
  if (id) await db.address.updateMany({ where: { id, userId: u.id }, data: d })
  else await db.address.create({ data: { ...d, userId: u.id } })
  revalidatePath('/account/profile')
}
export async function deleteAddress(f: FormData) {
  const u = await requireUser('/account/profile')
  await db.address.deleteMany({ where: { id: Number(f.get('id')), userId: u.id } })
  revalidatePath('/account/profile')
}
export async function payOrder(f: FormData) {
  const u = await requireUser()
  const id = Number(f.get('id'))
  await db.order.updateMany({ where: { id, userId: u.id, status: 'PENDING' }, data: { status: 'PAID' } })
  revalidatePath('/order/' + id)
}
export async function setOrderStatus(f: FormData) {
  await requireAdmin()
  const id = Number(f.get('id')), status = s(f, 'status')
  if (!['PENDING', 'PAID', 'SHIPPED', 'DELIVERED', 'CANCELLED'].includes(status)) return
  await db.$transaction(async tx => {
    const o = await tx.order.findUnique({ where: { id }, include: { items: true } })
    if (!o) return
    if (status === 'CANCELLED' && o.status !== 'CANCELLED')
      for (const i of o.items) await tx.product.update({ where: { id: i.productId }, data: { stock: { increment: i.quantity } } })
    if (o.status === 'CANCELLED' && status !== 'CANCELLED')
      for (const i of o.items) {
        const r = await tx.product.updateMany({ where: { id: i.productId, stock: { gte: i.quantity } }, data: { stock: { decrement: i.quantity } } })
        if (!r.count) throw new Error('สต็อกไม่พอสำหรับเปิดออเดอร์ใหม่')
      }
    await tx.order.update({ where: { id }, data: { status } })
  })
  revalidatePath('/admin/orders'); revalidatePath('/admin/orders/' + id)
}
export async function saveProduct(f: FormData) {
  await requireAdmin()
  const id = s(f, 'id')
  const d = { name: s(f, 'name'), description: s(f, 'description'), price: Number(f.get('price')), stock: Math.max(0, Number(f.get('stock')) | 0), lowStockThreshold: Math.max(0, Number(f.get('low')) | 0), imageUrl: s(f, 'imageUrl') || '💊', categoryId: Number(f.get('categoryId')), isActive: f.get('isActive') === 'on' }
  if (!d.name || !(d.price > 0)) return
  if (id === 'new') await db.product.create({ data: d })
  else await db.product.update({ where: { id: Number(id) }, data: d })
  revalidatePath('/', 'layout')
  redirect('/admin/products')
}
export async function deleteProduct(f: FormData) {
  await requireAdmin()
  const id = Number(f.get('id'))
  if (await db.orderItem.count({ where: { productId: id } })) await db.product.update({ where: { id }, data: { isActive: false } })
  else await db.product.delete({ where: { id } })
  revalidatePath('/', 'layout')
}
