import './globals.css'
import Link from 'next/link'
import type { Metadata } from 'next'
import { getUser } from '@/lib/auth'
import { CartProvider, CartLink } from '@/components/cart'
export const metadata: Metadata = { title: 'Flow Lab – วิตามินและอาหารเสริม', icons: '/logo-mark.png' }
export const dynamic = 'force-dynamic'
export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const u = await getUser()
  return (
    <html lang="th">
      <head><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;600;800&display=swap" /></head>
      <body className="bg-slate-50 font-['Noto_Sans_Thai',sans-serif] text-slate-900">
        <CartProvider>
          <header className="flex flex-wrap items-center gap-4 bg-navy px-5 py-2 text-white">
            <Link href="/" className="mr-auto flex items-center gap-2 text-xl font-extrabold"><img src="/logo-mark.png" alt="" className="h-8 w-auto" />Flow Lab</Link>
            <Link href="/">สินค้า</Link>
            <CartLink />
            {u ? <>
              {u.role === 'ADMIN' && <Link href="/admin">แอดมิน</Link>}
              <Link href="/account">{u.name}</Link>
              <form action="/api/auth/logout" method="post"><button>ออกจากระบบ</button></form>
            </> : <><Link href="/login">เข้าสู่ระบบ</Link><Link href="/register">สมัครสมาชิก</Link></>}
          </header>
          <main className="mx-auto max-w-5xl p-5">{children}</main>
        </CartProvider>
      </body>
    </html>
  )
}
