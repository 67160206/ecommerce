import Link from 'next/link'
import { db } from '@/lib/db'
import { baht } from '@/lib/utils'
import { Card, StatusBadge, Table, btn } from '@/components/ui'
import RevenueChart from '@/components/revenue-chart'
export default async function Dashboard() {
  const [orders, products] = await Promise.all([db.order.findMany({ include: { user: true }, orderBy: { id: 'desc' } }), db.product.findMany({ where: { isActive: true } })])
  const ok = orders.filter(o => o.status !== 'CANCELLED')
  const low = products.filter(p => p.stock <= p.lowStockThreshold)
  const day = (d: Date) => d.toISOString().slice(0, 10)
  const daily = [...Array(7)].map((_, i) => { const d = day(new Date(Date.now() - (6 - i) * 864e5)); return { date: d.slice(5), revenue: ok.filter(o => day(o.createdAt) === d).reduce((a, o) => a + o.totalAmount, 0) } })
  const stats: [string, string | number][] = [['รายได้รวม', baht(ok.reduce((a, o) => a + o.totalAmount, 0))], ['จำนวนออเดอร์', orders.length], ['รอจัดการ', orders.filter(o => ['PENDING', 'PAID'].includes(o.status)).length], ['สินค้าใกล้หมด', low.length]]
  return <div>
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{stats.map(([l, v]) => <Card key={l}><span className="text-sm text-slate-500">{l}</span><b className="block text-2xl">{v}</b></Card>)}</div>
    <h2 className="mb-2 mt-6 font-bold">รายได้ 7 วันล่าสุด</h2><Card><RevenueChart data={daily} /></Card>
    <div className="mt-6 grid gap-6 md:grid-cols-2">
      <div><h2 className="mb-2 font-bold">ออเดอร์ล่าสุด</h2>{orders.length ? <Table><tbody>{orders.slice(0, 6).map(o => <tr key={o.id}><td><Link href={`/admin/orders/${o.id}`} className="text-brand">#{o.id}</Link></td><td>{o.shippingName}</td><td>{baht(o.totalAmount)}</td><td><StatusBadge s={o.status} /></td></tr>)}</tbody></Table> : <p className="text-slate-500">ยังไม่มีออเดอร์</p>}</div>
      <div><h2 className="mb-2 font-bold">สินค้าใกล้หมด</h2>{low.length ? <Table><tbody>{low.map(p => <tr key={p.id} className="bg-red-50"><td>{p.name}</td><td>เหลือ {p.stock}</td><td><Link href={`/admin/products/${p.id}`} className={btn('outline', 'px-3 py-1')}>แก้สต็อก</Link></td></tr>)}</tbody></Table> : <p className="text-slate-500">สต็อกปกติทุกรายการ</p>}</div>
    </div></div>
}
