# Flow Lab – เว็บขายวิตามินและอาหารเสริม

Next.js 14 (App Router) + TypeScript · Prisma + SQLite · Tailwind + คอมโพเนนต์สไตล์ shadcn/ui · Recharts · JWT (jose) + cookie

## รันด้วย Docker
    docker compose up --build
เปิด http://localhost:8080  (ตั้ง AUTH_SECRET=ค่าลับ ก่อนใช้งานจริง)

## รันเองบนเครื่อง
    npm install
    echo 'DATABASE_URL="file:./dev.db"' > .env
    npx prisma db push && npx prisma db seed && npm run dev

## บัญชีทดลอง
admin@shop.test / admin123 · user@shop.test / user123

## REST API
GET /api/products?q=&category= · GET /api/products/:id · GET /api/categories · GET /api/health
POST /api/auth/login|register|logout · GET/POST /api/orders (ต้องล็อกอิน)
ส่วนแอดมิน (สินค้า/ออเดอร์/ที่อยู่) ใช้ Server Actions ใน app/actions.ts ที่ตรวจสิทธิ์ฝั่งเซิร์ฟเวอร์ทุกครั้ง

## ความปลอดภัย
bcrypt · JWT httpOnly cookie · requireUser/requireAdmin ฝั่งเซิร์ฟเวอร์ · ราคาดึงจากฐานข้อมูล · สร้างออเดอร์+ตัดสต็อกใน transaction เดียว
